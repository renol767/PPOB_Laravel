<p>TEST</p>
<div>
    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
        onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();">
        LOGOUT
    </a>
    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
        <?php echo csrf_field(); ?>
    </form>
</div><?php /**PATH D:\Kuliah\NuPay\ppob\resources\views/dashboard/index.blade.php ENDPATH**/ ?>